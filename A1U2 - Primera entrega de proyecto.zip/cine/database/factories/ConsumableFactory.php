<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Consumable;
use Faker\Generator as Faker;

$factory->define(Consumable::class, function (Faker $faker) {
    return [
        //
    ];
});
