@extends('layout.layout')


<link href="{{ asset('css/carousel.css') }}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">



@section('content')

    <div class="col-12">
    @include('layouts.carousel')
    </div>



{{--    <div class="row">--}}
{{--        <div class="col-1 bg-danger">1</div>--}}
{{--        <div class="col-1 bg-dark">2</div>--}}
{{--        <div class="col-1 bg-info">3</div>--}}
{{--        <div class="col-1 bg-primary">4</div>--}}
{{--        <div class="col-1 bg-success">5</div>--}}
{{--        <div class="col-1 bg-secondary">6</div>--}}
{{--        <div class="col-1 bg-success">7</div>--}}
{{--        <div class="col-1 bg-secondary">8</div>--}}
{{--        <div class="col-1 bg-info">9</div>--}}
{{--        <div class="col-1 bg-danger">10</div>--}}
{{--        <div class="col-1 bg-primary">11</div>--}}
{{--        <div class="col-4 bg-info">12</div>--}}
{{--    </div>--}}


<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo.... ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/7.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">La habitación</h3>

                <p class="mb-auto">Matt y Kate compran una casa aislada. 
                A medida que se mudan, descubren una habitación extraña que 
                les da un número ilimitado de deseos materiales. Pero lo que más 
                desean es tener un niño....</p>
                <a href="{{ url('/movies') }}" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/8.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>
<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/7.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">Mulán (2020)</h3>

                <p class="mb-auto">Cuando el emperador de China lanza un decreto de que un hombre por familia debe
                    servir al Ejército Imperial ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/8.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>
<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/7.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">Mulán (2020)</h3>

                <p class="mb-auto">Cuando el emperador de China lanza un decreto de que un hombre por familia debe
                    servir al Ejército Imperial ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="{{ asset('img/8.jpg') }}" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>


<!-- Agregar JavaScript -->
<script type="text/javascript" src="{{ asset('js/app.js') }}"></script>

@endsection
