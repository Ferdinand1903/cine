<div>

<link rel="stylesheet" href="<?php echo e(asset('css/carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>


<div id="myCarousel" class="carousel slide carousel-fade col-12" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="<?php echo e(asset('img/1.jpg')); ?>" style="height: 630px">
            <div class="container">
                <div class="carousel-caption text-left">
                    <h1><font color="black">Bienvenido a CineFlix.</font></h1>
                    <p><font color="black">Crated by FERDINAND.</font></p>
                    <p><a class="btn btn-danger btn-lg" href="#" role="button">Compra tu entrada</a></p>
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('img/3.jpg')); ?>" alt="" style="height: 768px">
            <div class="container">
                <div class="carousel-caption text-right">
                    <h1><font color="red">Disfruta de Peliculas de Cine Independiente.</font></h1>
                    <p><font color="purple">Numerosas películas no se producen ni se distribuyen por los canales comerciales
                     convencionales y por ello son etiquetadas con una denominación diferente, 
                     cine independiente.</font></p>
                    <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('img/2.jpg')); ?>" style="height: 768px">
            <div class="container">
                <div class="carousel-caption text-right">
                    <h1>Gran variedad de alimentos.</h1>
                    <p>Prohibido entrar con alimentos.</p>
                    <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
                </div>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

</div>
<?php /**PATH /home/ferdinand/cine/resources/views/layouts/carousel.blade.php ENDPATH**/ ?>