<?php $__env->startSection('title', 'Películas'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="row">
            <div class="col-sm-2">
                <a href="<?php echo e(route('movies.create')); ?>">
                    <button class="btn btn-primary">Agregar</button>
                </a>
            </div>
            <div class="col-sm-10"><h1>Películas registradas</h1></div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row">
                <div class="card col-sm bg-light" style="width: 18rem;">
                    <img src="..." class="card-img7-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($movie->name); ?></h5>
                        <h3 class="card-text"><?php echo e($movie->director); ?></h3>
                        <p class="card-text"><?php echo e($movie->synopsis); ?></p>
                        <p class="card-text text-muted"><?php echo e($movie->duration); ?></p>
                        <form action="<?php echo e(route('movies.destroy', $movie->id)); ?>" method="post">
                            <a class="btn btn-secondary" href="<?php echo e(route('movies.show', $movie->id)); ?>">Ver</a>
                            <a class="btn btn-secondary" href="<?php echo e(route('movies.edit', $movie->id)); ?>">Editar</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </div>
                </div>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div><h3>NO HAY REGISTROS DE PELÍCULAS EN LA BASE DE DATOS</h3></div>
        <?php endif; ?>

        <?php echo e($movies->links()); ?>


        <?php $__env->stopSection(); ?>


    </div>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ferdinand/cine/resources/views/movies/index.blade.php ENDPATH**/ ?>