<link href="<?php echo e(asset('css/carousel.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">



<?php $__env->startSection('content'); ?>

    <div class="col-12">
    <?php echo $__env->make('layouts.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



















<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo.... ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/7.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">La habitación</h3>

                <p class="mb-auto">Matt y Kate compran una casa aislada. 
                A medida que se mudan, descubren una habitación extraña que 
                les da un número ilimitado de deseos materiales. Pero lo que más 
                desean es tener un niño....</p>
                <a href="<?php echo e(url('/movies')); ?>" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/8.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>
<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/7.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">Mulán (2020)</h3>

                <p class="mb-auto">Cuando el emperador de China lanza un decreto de que un hombre por familia debe
                    servir al Ejército Imperial ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/8.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>
<div class="row">

    <div class="col-1"></div>

    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-success"></strong>
                <h3 class="mb-0 text-uppercase">Nación cautiva</h3>

                <p class="mb-auto">Hace 10 años, los alienígenas ocuparon el planeta 
                arrebatándoselo a los humanos. Ahora, desde un barrio de Chicago, 
                un grupo de rebeldes intenta recuperarlo ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/7.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div
            class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0 text-uppercase">Mulán (2020)</h3>

                <p class="mb-auto">Cuando el emperador de China lanza un decreto de que un hombre por familia debe
                    servir al Ejército Imperial ...</p>
                <a href="#" class="stretched-link">
                    <button class="btn btn-info btn-sm">Leer más</button>
                </a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo e(asset('img/8.jpg')); ?>" width="200px" alt="">
            </div>
        </div>
    </div>

    <div class="col-1"></div>

</div>


<!-- Agregar JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ferdinand/cine/resources/views/welcome.blade.php ENDPATH**/ ?>